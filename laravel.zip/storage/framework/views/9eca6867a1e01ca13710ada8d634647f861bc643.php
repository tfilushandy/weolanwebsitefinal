
<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row">
    <div class="col col-12 mb-2">
      <div class="card">
        <div class="card-header" style="border:none; background:linear-gradient(to right, #3354e7, slategray);">
          <div class="row">
            <div class="col" >
            ID GAME SETTING
            </div>
            <div class="col-auto">
              <a href="<?php echo e(URL::to('checkout')); ?>" class="btn btn-sm btn-danger" style="color:white; background-color: #3399ff; border: 0px;">
                Tutup
              </a>
            </div>
          </div>
        </div>
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-stripped">
              <thead>
                <tr>
                  <th>ID GAME</th>
                  <th>NO WA</th>
                  <th>EMAIL</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
              <?php $__currentLoopData = $itemalamatpengiriman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pengiriman): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
        <td>
          <?php echo e($pengiriman->idgame); ?>

        </td>
        <td>
          <?php echo e($pengiriman->no_tlp); ?>

        </td>
        <td>
          <?php echo e($pengiriman->email); ?>

        </td>
                  <td>
                    <form action="<?php echo e(route('alamatpengiriman.update',$pengiriman->id)); ?>" method="post">
                      <?php echo method_field('patch'); ?>
                      <?php echo csrf_field(); ?>
                      <?php if($pengiriman->status == 'utama'): ?>
                      <button type="submit" class="btnsetutama btn-sm" style="background-color:#0099ff; color:white; border: 0px;" disabled>Utama</button>
                      <?php else: ?>
                      <button type="submit" class="btnsetutama btn-sm" style="background-color:grey; color:white; border: 0px;">Set Utama</button>
                      <?php endif; ?>
                    </form>
                  </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
    <div class="col col-12 mb-2">
      <div class="card">
        <div class="card-header" style="border:none; background:linear-gradient(to right, #3354e7, slategray);">
        ADD NEW ID GAME
        </div>
        <div class="card-body">
          <?php if(count($errors) > 0): ?>
          <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="alert alert-warning" ><?php echo e($error); ?></div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>
          <?php if($message = Session::get('error')): ?>
              <div class="alert alert-warning">
                  <p><?php echo e($message); ?></p>
              </div>
          <?php endif; ?>
          <?php if($message = Session::get('success')): ?>
              <div class="alert alert-success">
                  <p><?php echo e($message); ?></p>
              </div>
          <?php endif; ?>
          <form action="<?php echo e(route('alamatpengiriman.store')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="row">
              <div class="col">
                <div class="form-group">
                  <label for="IDGAME" style="color: black">ID GAME</label>
                  <input type="text" name="IDGAME" class="form-control" value=<?php echo e(old('IDGAME')); ?>>
                </div>
                <div class="form-group">
                  <label for="no_telp" style="color: black">NO WA</label>
                  <input type="text" name="no_tlp" class="form-control" value=<?php echo e(old('no_tlp')); ?>>
                </div>
                <div class="form-group">
                  <label for="EMAIL" style="color: black">EMAIL</label>
                  <input type="text" name="EMAIL" class="form-control" value=<?php echo e(old('EMAIL')); ?>>
                </div>
              </div>
              <div class="col">
                <div class="form-group">
                  <button type="submit" class="btn btn-primary" style="background-color:#3399ff; color: white;">Simpan</button>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laragon\laragon-zuma\www\weolanwebsitebug\resources\views/alamatpengiriman/index.blade.php ENDPATH**/ ?>